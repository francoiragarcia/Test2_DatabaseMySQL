package org.example;

import jakarta.persistence.*;
import java.util.Scanner;

public class App
{
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("Test2_FrancoGarcia_Database");
    public static void main( String[] args )
    {
        Scanner input = new Scanner(System.in);
        int exitNum = 1 ; // variable to keep repeating the menu

        do
        {   /* =============== CREATES A MENU FOR USER =============== */
            System.out.println("\nWELCOME TO OUR MUSIC TRACK DATABASE \n\n");
            System.out.println("Select an option: \n" +
                    "1. Search for price of a song/track\n" +
                    "2. Update price of a song/track\n" +
                    "3. Add a new song/track\n" +
                    "0. Exit program\n\n" +
                    "Enter your option: ");
            // Asks the users input
            int userChoice = input.nextInt();

            if (userChoice == 1) {
                // If user chooses option 1,
                // it will ask user for the song name
                // and it will show its price
                System.out.println("\n\nGET SONG/TRACK PRICE\n\n");
                System.out.println("Enter song/track name: ");
                String tName = input.nextLine();
                getTrackPrice(tName);

            } else if (userChoice == 2) {
                // If user chooses option 2,
                // it will ask user for the track ID
                // and the new price
                // It will update the track
                System.out.println("\n\nUPDATE SONG/TRACK PRICE\n\n");
                System.out.println("Enter the track ID: ");
                int tID = input.nextInt();
                System.out.println("Enter the new price: $");
                float tPrice = input.nextFloat();
                updateTrackPrice(tID, tPrice);

            } else if (userChoice == 3) {
                // Option 3,
                // It will ask the user for details
                // to add a new track
                System.out.println("\n\nADD A NEW SONG/TRACK\n\n");
                System.out.println("Enter song/track name: ");
                String trackName = input.nextLine();
                System.out.println("Enter album ID: ");
                int albumId = input.nextInt();
                System.out.println("Enter media type ID: ");
                int mediaTypeId = input.nextInt();
                System.out.println("Enter genre ID: ");
                int genreId = input.nextInt();
                System.out.println("Enter composer name(s): ");
                String composer = input.nextLine();
                System.out.println("Enter length in milliseconds: ");
                int milliseconds = input.nextInt();
                System.out.println("Enter file size in bytes: ");
                int bytes = input.nextInt();
                System.out.println("Enter price: $");
                float unitPrice = input.nextFloat();
                // Calls the Add track function to create a track
                addTrack(trackName, albumId, mediaTypeId, genreId, composer, milliseconds, bytes, unitPrice);
                System.out.println("\nA track has been successfully added!\n");


            } else if (userChoice == 0) {
                // Option 0.
                // This will exit the program
                System.out.println("\n\nThank you for using our Music Track Database!\n\n");
                exitNum = userChoice;

            } else {
                // Asks user to enter again...
                System.out.println("\nPlease enter a valid option.\n");
            }
        }while(exitNum!=0);
    }

//    customerId, companyName, contactName, contactTitle, address, city, region, postalCode, country, phoneNumber, faxNumber

    /* =============== Method to CREATE AND ADD A NEW TRACK =============== */
    public static void addTrack(String trackName,
                                int albumId,
                                int mediaTypeId,
                                int genreId,
                                String composer,
                                int milliseconds,
                                int bytes,
                                float unitPrice){
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = null;
        try{
            et = em.getTransaction();
            et.begin();
            Track emp = new Track();
            emp.setTrackName(trackName);
            emp.setAlbumId(albumId);
            emp.setMediaTypeId(mediaTypeId);
            emp.setGenreId(genreId);
            emp.setComposer(composer);
            emp.setMilliseconds(milliseconds);
            emp.setBytes(bytes);
            emp.setUnitPrice(unitPrice);
            em.persist(emp);
            et.commit();
        }catch (Exception ex){
            if(et!=null){
                et.rollback();
            }
        }finally {
            em.close();
        }
    }

    /* =============== Method to FETCH TRACK DETAILS =============== */
    public static void getTrackPrice(String id){
        EntityManager em = emf.createEntityManager();
        try{

            TypedQuery<Track> tq = em.createQuery("select t from Track t where t.TrackName=:id", Track.class);
            tq.setParameter("id", id);
            Track t = tq.getSingleResult();
            System.out.println("\n\nHere it is: " +
                               "Track: " + id + "\n" +
                               "Price: $" + t.getUnitPrice() + "\n");
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            {
                em.close();
            }
        }
    }

    /* =============== Method to UPDATE TRACK PRICE =============== */
    public static void updateTrackPrice(int id, float newPrice){
        EntityManager em = emf.createEntityManager();
        try{
            TypedQuery<Track> tq = em.createQuery("update t.unitPrice from Track t where t.trackId=:id", Track.class);
            tq.setParameter("id", id);
            tq.setParameter("unitPrice", newPrice);
            Track t = tq.getSingleResult();
            System.out.println("\nThe track price has been successfully updated!\n");
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            {
                em.close();
            }
        }
    }
}
