package org.example;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

@Entity
@Table(name="track")

public class Track {
    private static final long serialVersionUID = 1L;

    /* ===== Convert columns into Java variables ===== */
    @Id
    @Column(name="TrackID", unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int trackId;
    @Column(name="Name") private String trackName;
    @Column(name="AlbumId") private int albumId;
    @Column(name="MediaTypeId") private int mediaTypeId;
    @Column(name="GenreId") private int genreId;
    @Column(name="Composer") private String composer;
    @Column(name="Milliseconds") private int milliseconds;
    @Column(name="Bytes") private int bytes;
    @Column(name="UnitPrice") private float unitPrice;

    /* ===== Creates the get attribute for each column ===== */
    public static long getSerialVersionUID() { return serialVersionUID; }
    public int getTrackId() { return trackId; }
    public String getTrackName() { return  trackName; }
    public int getAlbumId() { return albumId; }
    public int getMediaTypeId() { return mediaTypeId; }
    public int getGenreId() { return genreId; }
    public String getComposer() { return composer; }
    public int getMilliseconds() { return milliseconds; }
    public int getBytes() { return bytes; }
    public float getUnitPrice() { return unitPrice; }

    /* ===== Creates the set attribute for each column ===== */
    public void setTrackId(int trackId) { this.trackId = trackId; }
    public void setTrackName(String trackName) { this.trackName = trackName; }
    public void setAlbumId(int albumId) { this.albumId = albumId; }
    public void setMediaTypeId(int mediaTypeId) { this.mediaTypeId = mediaTypeId; }
    public void setGenreId(int genreId) { this.genreId = genreId; }
    public void setComposer(String composer) { this.composer = composer; }
    public void setMilliseconds(int milliseconds) { this.milliseconds = milliseconds; }
    public void setBytes(int bytes) { this.bytes = bytes; }
    public void setUnitPrice(float unitPrice) { this.unitPrice = unitPrice; }
}
